const express = require("express");
const path = require("path");
const multer = require("multer");
const app = express();
// const Jimp = require("jimp");
const fs = require("fs");
const cloudinary = require("cloudinary").v2;

// Configure Cloudinary with your credentials
cloudinary.config({
  cloud_name: "dlm56y4v4",
  api_key: "951956927266542",
  api_secret: "4MjWYAfCl4gO_BmCUWaxjRxPAHU",
});

const multerMiddleWareStorage = multer.diskStorage({
  destination: (req, res, callBack) => {
    callBack(null, "uploads/");
  },
  filename: (req, file, callBack) => {
    callBack(null, Date.now() + path.extname(file.originalname));
    // callBack(null, Date.now() + ".png");
  },
});
const fileFilter = (req, file, callBack) => {
  const allowedFileTypes = [
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/gif",
  ];
  if (allowedFileTypes.includes(file.mimetype)) {
    callBack(null, true);
  } else {
    callBack(null, false);
  }
};
const upload = multer({
  storage: multerMiddleWareStorage,
  limits: {
    fileSize: 1000000000, // 1000000000 Bytes = 1000 MB
  },
  fileFilter: fileFilter,
});
// Function to convert image to PNG
// async function convertToPNG1(imagePath) {
//   const image = await Jimp.read(imagePath);
//   const outputImagePath = imagePath.replace(/\.[^/.]+$/, ".png");

//   // Write the image to the new PNG file
//   await image.writeAsync(outputImagePath);

//   // Delete the original JPEG file
//   try {
//     fs.unlinkSync(imagePath);
//     console.log(`File ${imagePath} deleted.`);
//   } catch (err) {
//     console.error(`Error deleting file ${imagePath}:`, err);
//   }
//   // const outputImagePath = imagePath.replace(/\.[^/.]+$/, ".png");

//   // Write the image to the new PNG file
//   // await image.writeAsync(outputImagePath, (err) => {
//   //   if (err) {
//   //     console.error(`Error writing file ${outputImagePath}:`, err);
//   //   } else {
//   //     console.log(`File ${outputImagePath} written.`);

//   //     // Delete the original JPEG file
//   //     fs.unlink(imagePath, (err) => {
//   //       if (err) {
//   //         console.error(`Error deleting file ${imagePath}:`, err);
//   //       } else {
//   //         console.log(`File ${imagePath} deleted.`);
//   //       }
//   //     });
//   //   }
//   // });
//   return outputImagePath;
// }
function convertToPNG(imagePath) {
  const outputImagePath = imagePath.replace(/\.[^/.]+$/, ".png");

  gm(imagePath).write(outputImagePath, function (err) {
    if (!err) {
      console.log(`File ${outputImagePath} written.`);

      // Delete the original file
      fs.unlink(imagePath, (err) => {
        if (err) {
          console.error(`Error deleting file ${imagePath}:`, err);
        } else {
          console.log(`File ${imagePath} deleted.`);
        }
      });
    } else {
      console.error(`Error converting image to PNG:`, err);
    }
  });

  return outputImagePath;
}
// async function convertToPNG1(imagePath) {
//   try {
//     const result = await cloudinary.uploader.upload(imagePath, {
//       format: "png"
//     });
//     return result.url;
//   } catch (error) {
//     console.error("Error converting image:", error);
//     throw error;
//   }
// }

const UploadImage = app.post("/", upload.single("image"), async (req, res) => {
  try {
    const imageUpload = req.file.path;
    // if (path.extname(imageUpload).toLowerCase() === ".png") {
    //   res.json({ path: imageUpload });
    // } else {
    //   const convertedImagePath = await convertToPNG1(imageUpload);
    //   res.json({ path: convertedImagePath });
    // }
    // const convertedImagePath = await convertToPNG(imageUpload);

    res.json({ path: imageUpload });
  } catch (error) {
    res.send(error);
  }
});
module.exports = UploadImage;
